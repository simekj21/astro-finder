<template>
  <div class="p-4">
    <!-- Tabs (sticky) -->
    <div
      :class="[
        'sticky top-0 bg-white z-10 pb-2 mb-4 transition-shadow duration-300',
        hasShadow ? 'shadow-md' : '',
      ]"
    >
      <!-- 1. skupina: Groups, Users, Result -->
      <div
        class="mb-4 p-3 rounded-lg bg-blue-50 border border-blue-200 flex space-x-4 items-center"
      >
        <button
          v-for="tab in firstRowTabs"
          :key="tab.name"
          @click="activeTab = tab.name"
          :class="[
            'pb-2 px-4 font-semibold rounded',
            activeTab === tab.name
              ? 'border-b-2 border-blue-500 text-blue-600 bg-blue-100'
              : 'text-gray-600 hover:text-blue-500 hover:bg-blue-100',
          ]"
        >
          {{ tab.label }}
        </button>

        <!-- Výběr aktivního uživatele -->
        <div class="ml-auto flex items-center gap-2 text-sm">
          <label for="activeUser">Active user:</label>
          <select
            id="activeUser"
            v-model="activeUserId"
            class="p-1 border rounded"
          >
            <option disabled value="">-- Select --</option>
            <option v-for="u in users" :key="u.id" :value="u.id">
              {{ u.name }}
            </option>
          </select>
        </div>
      </div>

      <!-- 2. skupina: výkladové komponenty -->
      <div
        class="p-3 rounded-lg bg-green-50 border border-green-200 flex flex-wrap space-x-4"
      >
        <button
          v-for="tab in secondRowTabs"
          :key="tab.name"
          @click="activeTab = tab.name"
          :class="[
            'pb-2 px-4 font-semibold mb-1 rounded',
            activeTab === tab.name
              ? 'border-b-2 border-green-500 text-green-600 bg-green-100'
              : 'text-gray-600 hover:text-green-500 hover:bg-green-100',
          ]"
        >
          {{ tab.label }}
        </button>
      </div>
    </div>

    <!-- Obsah podle aktivní záložky -->
    <div>
      <planet-in-sign
        v-if="activeTab === 'planet'"
        :users="users"
        :activeUserId="activeUserId"
        @add-interpretation="addInterpretation"
      />
      <aspects
        v-if="activeTab === 'aspects'"
        :users="users"
        :activeUserId="activeUserId"
        @add-interpretation="addInterpretation"
      />
      <house-in-sign
        v-if="activeTab === 'sun'"
        :users="users"
        :activeUserId="activeUserId"
        @add-interpretation="addInterpretation"
      />
      <planet-in-house
        v-if="activeTab === 'phouses'"
        :users="users"
        :activeUserId="activeUserId"
        @add-interpretation="addInterpretation"
      />
      <synastry
        v-if="activeTab === 'synastry'"
        :users="users"
        :activeUserId="activeUserId"
        @add-interpretation="addInterpretation"
      />
      <div v-if="activeTab === 'users'">
        <Users
          :users="users"
          :groups="groups"
          @update:users="users = $event"
          @update:groups="groups = $event"
        />
      </div>
      <div v-if="activeTab === 'groups'">
        <Groups
          :groups="groups"
          :users="users"
          @update:groups="groups = $event"
        />
      </div>
      <result-tab
        v-if="activeTab === 'result'"
        :users="users"
        :groups="groups"
        :activeUserId="activeUserId"
      />
    </div>
  </div>
</template>

<script setup>
import { ref, watch, onMounted, onBeforeUnmount } from "vue";
import PlanetInSign from "./components/PlanetInSign.vue";
import PlanetInHouse from "./components/PlanetInHouse.vue";
import Aspects from "./components/Aspects.vue";
import HouseInSign from "./components/HouseInSign.vue";
import Synastry from "./components/Synastry.vue";
import Groups from "./components/Groups.vue";
import Users from "./components/Users.vue";
import ResultTab from "./components/Result.vue";

const firstRowTabs = [
  { name: "groups", label: "Groups" },
  { name: "users", label: "Users" },
  { name: "result", label: "Result" },
];
const secondRowTabs = [
  { name: "planet", label: "Planety Zn." },
  { name: "aspects", label: "Aspekty" },
  { name: "sun", label: "Domy" },
  { name: "phouses", label: "Planety Dom." },
  { name: "synastry", label: "Synastry" },
];

const activeTab = ref("planet");
const activeUserId = ref("");

const users = ref([]);
const groups = ref([
  { id: "group_1", name: "Family", users: [] },
  { id: "group_2", name: "Friends", users: [] },
  { id: "group_3", name: "Job", users: [] },
  { id: "group_4", name: "Clients", users: [] },
  { id: "group_5", name: "Celebrites", users: [] },
  { id: "group_6", name: "Group1", users: [] },
  { id: "group_7", name: "Group2", users: [] },
]);

function addInterpretation(item) {
  const user = users.value.find((u) => u.id === activeUserId.value);
  if (user) {
    if (!user.results) user.results = [];
    user.results.push(item);
  }
}

const hasShadow = ref(false);
function onScroll() {
  hasShadow.value = window.scrollY > 0;
}
onMounted(() => window.addEventListener("scroll", onScroll));
onBeforeUnmount(() => window.removeEventListener("scroll", onScroll));
</script>
